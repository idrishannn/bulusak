// ============================================
// BULUŞAK - UI Context
// ============================================

import React, { createContext, useContext, useState, useCallback } from 'react';

const UIContext = createContext(null);

export const UIProvider = ({ children }) => {
  const [bildirim, setBildirim] = useState(null);
  const [modalAcik, setModalAcik] = useState(null);
  const [modalData, setModalData] = useState(null);
  const [aktifSayfa, setAktifSayfa] = useState('feed');
  const [seciliGrup, setSeciliGrup] = useState(null);
  const [seciliEtkinlik, setSeciliEtkinlik] = useState(null);
  const [seciliZaman, setSeciliZaman] = useState(null);
  const [canSikildiModu, setCanSikildiModu] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [islemYukleniyor, setIslemYukleniyor] = useState(false);

  const bildirimGoster = useCallback((mesaj, tip = 'basari', sure = 3000) => {
    setBildirim({ mesaj, tip });
    setTimeout(() => setBildirim(null), sure);
  }, []);

  const bildirimKapat = useCallback(() => setBildirim(null), []);

  const modalAc = useCallback((modalAdi, data = null) => {
    setModalAcik(modalAdi);
    setModalData(data);
  }, []);

  const modalKapat = useCallback(() => {
    setModalAcik(null);
    setModalData(null);
  }, []);

  const sayfaDegistir = useCallback((sayfa) => setAktifSayfa(sayfa), []);
  const canSikildiToggle = useCallback(() => setCanSikildiModu(prev => !prev), []);
  const temaDegistir = useCallback(() => setDarkMode(prev => !prev), []);

  const value = {
    bildirim, bildirimGoster, bildirimKapat,
    modalAcik, modalData, modalAc, modalKapat, setModalAcik,
    aktifSayfa, setAktifSayfa, sayfaDegistir,
    seciliGrup, setSeciliGrup,
    seciliEtkinlik, setSeciliEtkinlik,
    seciliZaman, setSeciliZaman,
    canSikildiModu, setCanSikildiModu, canSikildiToggle,
    darkMode, temaDegistir,
    islemYukleniyor, setIslemYukleniyor
  };

  return <UIContext.Provider value={value}>{children}</UIContext.Provider>;
};

export const useUI = () => {
  const context = useContext(UIContext);
  if (!context) throw new Error('useUI must be used within a UIProvider');
  return context;
};

export default UIContext;
