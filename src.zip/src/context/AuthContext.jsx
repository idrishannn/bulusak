// ============================================
// BULUŞAK - Auth Context
// ============================================

import React, { createContext, useContext, useState, useEffect } from 'react';
import { auth } from '../services/firebase';
import { googleIleGiris, emailIleGiris, emailIleKayitOl, cikisYap, authDurumuDinle } from '../services/authService';
import { kullaniciBilgisiGetir, profilGuncelle, avatarGuncelle, kullaniciAdiKontrol } from '../services/userService';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [kullanici, setKullanici] = useState(null);
  const [yukleniyor, setYukleniyor] = useState(true);
  const [girisYapildi, setGirisYapildi] = useState(false);
  const [kayitAsamasi, setKayitAsamasi] = useState('giris');
  const [hata, setHata] = useState(null);

  useEffect(() => {
    const unsubscribe = authDurumuDinle(async (firebaseUser) => {
      if (firebaseUser) {
        const userData = await kullaniciBilgisiGetir(firebaseUser.uid);
        if (userData && userData.profilTamamlandi) {
          setKullanici({ ...userData, id: firebaseUser.uid, odUserId: firebaseUser.uid });
          setGirisYapildi(true);
          setKayitAsamasi('giris');
        } else if (userData) {
          setKullanici({ ...userData, id: firebaseUser.uid, odUserId: firebaseUser.uid });
          setGirisYapildi(false);
          setKayitAsamasi('avatar');
        } else {
          setKullanici(null);
          setGirisYapildi(false);
          setKayitAsamasi('avatar');
        }
      } else {
        setKullanici(null);
        setGirisYapildi(false);
        setKayitAsamasi('giris');
      }
      setYukleniyor(false);
    });
    return () => unsubscribe();
  }, []);

  const googleIleGirisYap = async () => {
    setYukleniyor(true);
    setHata(null);
    try {
      const result = await googleIleGiris();
      if (result.success) {
        if (result.isNewUser) { setKayitAsamasi('avatar'); }
        else if (result.userData?.profilTamamlandi) {
          setKullanici({ ...result.userData, id: result.user.uid, odUserId: result.user.uid });
          setGirisYapildi(true);
        } else { setKayitAsamasi('avatar'); }
        return { success: true };
      } else {
        setHata(result.error);
        return { success: false, error: result.error };
      }
    } catch (error) {
      setHata(error.message);
      return { success: false, error: error.message };
    } finally { setYukleniyor(false); }
  };

  const emailIleGirisYap = async (email, sifre) => {
    setYukleniyor(true);
    setHata(null);
    try {
      const result = await emailIleGiris(email, sifre);
      if (result.success) {
        if (result.userData?.profilTamamlandi) {
          setKullanici({ ...result.userData, id: result.user.uid, odUserId: result.user.uid });
          setGirisYapildi(true);
        } else { setKayitAsamasi('avatar'); }
        return { success: true };
      } else {
        setHata(result.error);
        return { success: false, error: result.error };
      }
    } catch (error) {
      setHata(error.message);
      return { success: false, error: error.message };
    } finally { setYukleniyor(false); }
  };

  const emailIleKayitOlFunc = async (email, sifre, isim) => {
    setYukleniyor(true);
    setHata(null);
    try {
      const result = await emailIleKayitOl(email, sifre, isim);
      if (result.success) { setKayitAsamasi('avatar'); return { success: true }; }
      else { setHata(result.error); return { success: false, error: result.error }; }
    } catch (error) {
      setHata(error.message);
      return { success: false, error: error.message };
    } finally { setYukleniyor(false); }
  };

  const profilTamamla = async (data) => {
    if (!auth.currentUser) return { success: false, error: 'Oturum bulunamadı' };
    setYukleniyor(true);
    setHata(null);
    try {
      const userId = auth.currentUser.uid;
      if (data.kullaniciAdi) {
        const kontrol = await kullaniciAdiKontrol(data.kullaniciAdi, userId);
        if (!kontrol.available) { setHata(kontrol.error); setYukleniyor(false); return { success: false, error: kontrol.error }; }
      }
      const result = await profilGuncelle(userId, { ...data, profilTamamlandi: true });
      if (result.success) {
        setKullanici({ ...kullanici, ...data, id: userId, odUserId: userId, profilTamamlandi: true });
        setGirisYapildi(true);
        setKayitAsamasi('giris');
        return { success: true };
      } else { setHata(result.error); return { success: false, error: result.error }; }
    } catch (error) {
      setHata(error.message);
      return { success: false, error: error.message };
    } finally { setYukleniyor(false); }
  };

  const avatarDegistir = async (avatar) => {
    if (!kullanici?.id) return { success: false, error: 'Oturum bulunamadı' };
    try {
      const result = await avatarGuncelle(kullanici.id, avatar);
      if (result.success) { setKullanici(prev => ({ ...prev, avatar })); return { success: true }; }
      else return { success: false, error: result.error };
    } catch (error) { return { success: false, error: error.message }; }
  };

  const profilBilgisiGuncelle = async (data) => {
    if (!kullanici?.id) return { success: false, error: 'Oturum bulunamadı' };
    try {
      const result = await profilGuncelle(kullanici.id, data);
      if (result.success) { setKullanici(prev => ({ ...prev, ...data })); return { success: true }; }
      else return { success: false, error: result.error };
    } catch (error) { return { success: false, error: error.message }; }
  };

  const cikisYapFunc = async () => {
    try { await cikisYap(); setKullanici(null); setGirisYapildi(false); setKayitAsamasi('giris'); return { success: true }; }
    catch (error) { return { success: false, error: error.message }; }
  };

  const value = {
    kullanici, yukleniyor, girisYapildi, kayitAsamasi, hata,
    setKayitAsamasi, setHata,
    googleIleGirisYap, emailIleGirisYap, emailIleKayitOl: emailIleKayitOlFunc, cikisYap: cikisYapFunc,
    profilTamamla, avatarDegistir, profilBilgisiGuncelle, kullaniciAdiKontrol
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};

export default AuthContext;
