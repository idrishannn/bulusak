import React from 'react';

const GaleriModal = ({ modalAcik, setModalAcik, galeri, setGaleri, bildirimGoster, tema }) => {
  if (modalAcik !== 'galeri') return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center">
      <div className={`${tema.bgCard} rounded-t-3xl w-full max-w-lg p-6 animate-slide-up border-t ${tema.border} max-h-[85vh] flex flex-col`}>
        <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
        
        <div className="flex items-center justify-between mb-4">
          <h3 className={`text-xl font-black ${tema.text}`}>📸 Anılar</h3>
          <button type="button" onClick={() => setModalAcik(null)} className={`w-10 h-10 rounded-xl ${tema.inputBg} flex items-center justify-center ${tema.text}`}>✕</button>
        </div>

        <button
          type="button"
          onClick={() => { setGaleri(prev => [...prev, { id: Date.now(), tarih: new Date().toLocaleDateString('tr-TR') }]); bildirimGoster('Fotoğraf eklendi! 📸'); }}
          className={`w-full ${tema.inputBg} border-2 border-dashed ${tema.border} rounded-2xl p-6 mb-4 flex flex-col items-center gap-2 ${tema.bgHover} transition-all`}
        >
          <span className="text-4xl">📷</span>
          <span className={`font-medium ${tema.text}`}>Fotoğraf Ekle</span>
        </button>

        <div className="flex-1 overflow-y-auto">
          {galeri.length > 0 ? (
            <div className="grid grid-cols-2 gap-3">
              {galeri.map(foto => (
                <div key={foto.id} className="relative rounded-2xl overflow-hidden aspect-square bg-gradient-to-br from-orange-200 to-amber-200">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-6xl">📸</span>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 bg-black/50 p-2">
                    <p className="text-white text-xs">{foto.tarih}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <span className="text-6xl">📷</span>
              <p className={`${tema.textSecondary} mt-4`}>Henüz fotoğraf yok</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default GaleriModal;
