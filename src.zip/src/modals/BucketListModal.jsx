import React, { useState } from 'react';

const BucketListModal = ({ modalAcik, setModalAcik, bucketList, setBucketList, bildirimGoster, tema }) => {
  const [yeniItem, setYeniItem] = useState('');
  const [yeniEmoji, setYeniEmoji] = useState('🎯');

  if (modalAcik !== 'bucketList') return null;

  const ekle = () => {
    if (!yeniItem.trim()) return;
    setBucketList(prev => [...prev, { id: Date.now(), baslik: yeniItem, tamamlandi: false, emoji: yeniEmoji }]);
    setYeniItem('');
    bildirimGoster('Listeye eklendi! ✨');
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center">
      <div className={`${tema.bgCard} rounded-t-3xl w-full max-w-lg p-6 animate-slide-up border-t ${tema.border} max-h-[85vh] flex flex-col`}>
        <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
        
        <div className="flex items-center justify-between mb-4">
          <h3 className={`text-xl font-black ${tema.text}`}>📋 Bucket List</h3>
          <button type="button" onClick={() => setModalAcik(null)} className={`w-10 h-10 rounded-xl ${tema.inputBg} flex items-center justify-center ${tema.text}`}>✕</button>
        </div>

        <div className="flex gap-2 mb-4">
          <select
            value={yeniEmoji}
            onChange={(e) => setYeniEmoji(e.target.value)}
            className={`w-14 ${tema.inputBg} ${tema.inputText} rounded-xl text-center text-xl`}
          >
            {['🎯', '🎈', '🎵', '⛺', '🏔️', '🎪', '🎭', '🎨', '🎬', '🍕'].map(e => (
              <option key={e} value={e}>{e}</option>
            ))}
          </select>
          <input
            type="text"
            value={yeniItem}
            onChange={(e) => setYeniItem(e.target.value)}
            placeholder="Birlikte yapmak istediğiniz şey..."
            onKeyPress={(e) => e.key === 'Enter' && ekle()}
            className={`flex-1 ${tema.inputBg} ${tema.inputText} rounded-xl px-4 py-3 focus:outline-none`}
          />
          <button type="button" onClick={ekle} className="w-12 h-12 bg-gradient-to-r from-orange-500 to-amber-500 rounded-xl flex items-center justify-center text-white text-xl">+</button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2">
          {bucketList.length > 0 ? bucketList.map(item => (
            <div 
              key={item.id}
              className={`flex items-center gap-3 p-4 rounded-2xl transition-all ${
                item.tamamlandi ? 'bg-green-50' : tema.inputBg
              }`}
            >
              <button 
                type="button"
                onClick={() => setBucketList(prev => prev.map(i => i.id === item.id ? { ...i, tamamlandi: !i.tamamlandi } : i))}
                className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                  item.tamamlandi ? 'bg-green-500 border-green-500 text-white' : 'border-gray-300'
                }`}
              >
                {item.tamamlandi && '✓'}
              </button>
              <span className="text-2xl">{item.emoji}</span>
              <span className={`flex-1 font-medium ${item.tamamlandi ? 'line-through text-gray-400' : tema.text}`}>
                {item.baslik}
              </span>
              <button type="button" onClick={() => setBucketList(prev => prev.filter(i => i.id !== item.id))} className={`${tema.textMuted} hover:text-red-500`}>🗑️</button>
            </div>
          )) : (
            <div className="text-center py-8">
              <span className="text-4xl">📝</span>
              <p className={`${tema.textSecondary} mt-2`}>Henüz bir şey eklenmedi</p>
            </div>
          )}
        </div>

        {bucketList.length > 0 && (
          <div className={`mt-4 pt-4 border-t ${tema.border} text-center`}>
            <span className={`${tema.textSecondary} text-sm`}>
              {bucketList.filter(i => i.tamamlandi).length}/{bucketList.length} tamamlandı 🎉
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default BucketListModal;
