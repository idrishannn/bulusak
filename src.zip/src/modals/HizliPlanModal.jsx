import React, { useState } from 'react';

const etkinlikIkonlari = { kahve: '☕', yemek: '🍕', film: '🎬', spor: '⚽', oyun: '🎮', parti: '🎉', toplanti: '💼', gezi: '🏖️', alisveris: '🛍️', konser: '🎵', diger: '📅' };
const grupIkonlari = ['🎓', '💼', '⚽', '🎮', '🎵', '🍕', '☕', '🎬', '🏖️', '🎉'];
const saatler = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00'];

const HizliPlanModal = ({ modalAcik, setModalAcik, gruplar, yeniGrupOlustur, yeniEtkinlikOlustur, islemYukleniyor, bildirimGoster, tema }) => {
  const [baslik, setBaslik] = useState('');
  const [secilenIkon, setSecilenIkon] = useState('kahve');
  const [seciliTarih, setSeciliTarih] = useState(new Date());
  const [seciliSaat, setSeciliSaat] = useState('15:00');
  const [mekan, setMekan] = useState('');
  const [secilenGrupId, setSecilenGrupId] = useState(gruplar[0]?.id);
  const [yeniGrupModu, setYeniGrupModu] = useState(false);
  const [yeniGrupAdi, setYeniGrupAdi] = useState('');
  const [yeniGrupEmoji, setYeniGrupEmoji] = useState('🎉');

  if (modalAcik !== 'hizliPlan') return null;

  const handleOlustur = async () => {
    if (!baslik.trim()) {
      bildirimGoster('Plan adı gerekli!', 'hata');
      return;
    }
    
    let hedefGrup;
    
    if (yeniGrupModu && yeniGrupAdi.trim()) {
      hedefGrup = await yeniGrupOlustur(yeniGrupAdi, yeniGrupEmoji, []);
      if (!hedefGrup) return;
    } else {
      hedefGrup = gruplar.find(g => g.id === secilenGrupId);
    }

    if (!hedefGrup) {
      bildirimGoster('Lütfen bir grup seç veya oluştur!', 'hata');
      return;
    }

    await yeniEtkinlikOlustur({
      baslik,
      ikon: secilenIkon,
      tarih: seciliTarih,
      saat: seciliSaat,
      mekan: mekan || 'Belirtilmedi',
      grup: hedefGrup
    });
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center">
      <div className={`${tema.bgCard} rounded-t-3xl w-full max-w-lg p-6 animate-slide-up border-t ${tema.border} max-h-[90vh] overflow-y-auto`}>
        <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
        
        <div className="flex items-center justify-between mb-6">
          <h3 className={`text-xl font-black ${tema.text}`}>⚡ Hızlı Plan</h3>
          <button type="button" onClick={() => setModalAcik(null)} className={`w-10 h-10 rounded-xl ${tema.inputBg} flex items-center justify-center ${tema.text}`}>✕</button>
        </div>

        <div className="mb-4">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>Plan Adı</label>
          <input
            type="text"
            value={baslik}
            onChange={(e) => setBaslik(e.target.value)}
            placeholder="Ne yapalım?"
            className={`w-full ${tema.inputBg} ${tema.inputText} rounded-2xl p-4 focus:outline-none focus:ring-2 focus:ring-orange-400`}
          />
        </div>

        <div className="mb-4">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>Kategori</label>
          <div className="flex flex-wrap gap-2">
            {Object.entries(etkinlikIkonlari).slice(0, 6).map(([key, icon]) => (
              <button
                key={key}
                type="button"
                onClick={() => setSecilenIkon(key)}
                className={`w-11 h-11 rounded-xl text-xl flex items-center justify-center transition-all ${
                  secilenIkon === key
                    ? 'bg-gradient-to-br from-orange-400 to-amber-400 shadow-lg scale-110'
                    : `${tema.inputBg} ${tema.bgHover}`
                }`}
              >
                {icon}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-4">
          <div>
            <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>📅 Tarih</label>
            <input
              type="date"
              value={seciliTarih.toISOString().split('T')[0]}
              onChange={(e) => setSeciliTarih(new Date(e.target.value))}
              className={`w-full ${tema.inputBg} ${tema.inputText} rounded-xl p-3 focus:outline-none`}
            />
          </div>
          <div>
            <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>⏰ Saat</label>
            <select
              value={seciliSaat}
              onChange={(e) => setSeciliSaat(e.target.value)}
              className={`w-full ${tema.inputBg} ${tema.inputText} rounded-xl p-3 focus:outline-none`}
            >
              {saatler.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>

        <div className="mb-4">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>👥 Grup</label>
          {!yeniGrupModu ? (
            <>
              {gruplar.length > 0 ? (
                <div className="flex gap-2 overflow-x-auto pb-2 mb-2">
                  {gruplar.map(g => (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() => setSecilenGrupId(g.id)}
                      className={`flex items-center gap-2 px-4 py-2 rounded-xl whitespace-nowrap transition-all ${
                        secilenGrupId === g.id
                          ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-lg'
                          : `${tema.inputBg} ${tema.text}`
                      }`}
                    >
                      <span>{g.emoji}</span>
                      <span className="font-medium">{g.isim}</span>
                    </button>
                  ))}
                </div>
              ) : (
                <p className={`${tema.textSecondary} text-sm mb-2`}>Henüz grup yok</p>
              )}
              <button
                type="button"
                onClick={() => setYeniGrupModu(true)}
                className={`w-full p-2 rounded-xl border-2 border-dashed border-orange-300 ${tema.text} text-sm font-medium flex items-center justify-center gap-2`}
              >
                ➕ Yeni Grup Oluştur
              </button>
            </>
          ) : (
            <div className={`${tema.inputBg} rounded-2xl p-4`}>
              <div className="flex items-center gap-2 mb-3">
                <button type="button" onClick={() => setYeniGrupModu(false)} className="text-orange-500">←</button>
                <span className={`font-bold ${tema.text}`}>Yeni Grup</span>
              </div>
              <input
                type="text"
                value={yeniGrupAdi}
                onChange={(e) => setYeniGrupAdi(e.target.value)}
                placeholder="Grup adı"
                className={`w-full ${tema.bgCard} ${tema.inputText} rounded-xl p-3 mb-3 border ${tema.border}`}
              />
              <div className="flex gap-2 flex-wrap">
                {grupIkonlari.map((emoji, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => setYeniGrupEmoji(emoji)}
                    className={`w-9 h-9 rounded-lg text-lg flex items-center justify-center ${
                      yeniGrupEmoji === emoji ? 'bg-orange-200' : tema.bgCard
                    }`}
                  >
                    {emoji}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="mb-6">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>📍 Mekan (Opsiyonel)</label>
          <input
            type="text"
            value={mekan}
            onChange={(e) => setMekan(e.target.value)}
            placeholder="Nerede buluşalım?"
            className={`w-full ${tema.inputBg} ${tema.inputText} rounded-xl p-3 focus:outline-none`}
          />
        </div>

        <button
          type="button"
          onClick={handleOlustur}
          disabled={islemYukleniyor}
          className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white py-4 rounded-2xl font-bold text-lg shadow-lg disabled:opacity-50"
        >
          {islemYukleniyor ? '⏳ Oluşturuluyor...' : 'Plan Oluştur 🚀'}
        </button>
      </div>
    </div>
  );
};

export default HizliPlanModal;
