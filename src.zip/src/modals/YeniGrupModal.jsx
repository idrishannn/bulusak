import React, { useState } from 'react';

const grupIkonlari = ['🎓', '💼', '⚽', '🎮', '🎵', '🍕', '☕', '🎬', '🏖️', '🎉', '👨‍👩‍👧‍👦', '🏋️', '📚', '🎨', '🚗', '✈️', '🏠', '💪', '🎸', '🍺'];

const YeniGrupModal = ({ modalAcik, setModalAcik, yeniGrupOlustur, islemYukleniyor, bildirimGoster, tema }) => {
  const [grupAdi, setGrupAdi] = useState('');
  const [secilenEmoji, setSecilenEmoji] = useState('🎉');

  if (modalAcik !== 'yeniGrup') return null;

  const handleOlustur = async () => {
    if (!grupAdi.trim()) {
      bildirimGoster('Grup adı gerekli!', 'hata');
      return;
    }
    
    const result = await yeniGrupOlustur(grupAdi, secilenEmoji, []);
    if (result) {
      setModalAcik(null);
      setGrupAdi('');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center">
      <div className={`${tema.bgCard} rounded-t-3xl w-full max-w-lg p-6 animate-slide-up border-t ${tema.border} max-h-[85vh] overflow-y-auto`}>
        <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
        
        <div className="flex items-center justify-between mb-6">
          <h3 className={`text-xl font-black ${tema.text}`}>👥 Yeni Grup Oluştur</h3>
          <button type="button" onClick={() => setModalAcik(null)} className={`w-10 h-10 rounded-xl ${tema.inputBg} flex items-center justify-center ${tema.text}`}>✕</button>
        </div>

        <div className="mb-4">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>Grup Adı</label>
          <input
            type="text"
            value={grupAdi}
            onChange={(e) => setGrupAdi(e.target.value)}
            placeholder="Cuma Akşamı Ekibi"
            className={`w-full ${tema.inputBg} ${tema.inputText} rounded-2xl p-4 border-2 border-transparent focus:border-orange-400 focus:outline-none`}
          />
        </div>

        <div className="mb-6">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>Grup İkonu</label>
          <div className="flex flex-wrap gap-2">
            {grupIkonlari.map((emoji, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setSecilenEmoji(emoji)}
                className={`w-11 h-11 rounded-xl text-xl flex items-center justify-center transition-all ${
                  secilenEmoji === emoji
                    ? 'bg-gradient-to-br from-orange-400 to-amber-400 shadow-lg scale-110'
                    : `${tema.inputBg} ${tema.bgHover}`
                }`}
              >
                {emoji}
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={handleOlustur}
          disabled={islemYukleniyor}
          className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white py-4 rounded-2xl font-bold text-lg shadow-lg disabled:opacity-50"
        >
          {islemYukleniyor ? '⏳ Oluşturuluyor...' : 'Grup Oluştur 🎉'}
        </button>
      </div>
    </div>
  );
};

export default YeniGrupModal;
