import React, { useState } from 'react';
import { mesajEkle } from '../services/etkinlikService';

const gunlerTam = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
const aylar = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const etkinlikIkonlari = { kahve: '☕', yemek: '🍕', film: '🎬', spor: '⚽', oyun: '🎮', parti: '🎉', toplanti: '💼', gezi: '🏖️', alisveris: '🛍️', konser: '🎵', diger: '📅' };

const EtkinlikDetayModal = ({ modalAcik, setModalAcik, seciliEtkinlik, setSeciliEtkinlik, kullanici, katilimDurumuGuncelle, tema }) => {
  const [yeniMesaj, setYeniMesaj] = useState('');

  if (modalAcik !== 'detay' || !seciliEtkinlik) return null;

  const tarih = new Date(seciliEtkinlik.tarih);
  const katilimcilar = seciliEtkinlik.katilimcilar || [];
  const varimSayisi = katilimcilar.filter(k => k.durum === 'varim').length;
  const kullanicininDurumu = katilimcilar.find(k => k.odUserId === kullanici?.odUserId)?.durum;

  const mesajGonder = async (e) => {
    if (e) e.preventDefault();
    if (!yeniMesaj.trim() || !seciliEtkinlik?.id) return;
    
    try {
      const sonuc = await mesajEkle(seciliEtkinlik.id, {
        odUserId: kullanici?.odUserId,
        isim: kullanici?.isim,
        avatar: kullanici?.avatar,
        mesaj: yeniMesaj
      });
      
      if (sonuc.success) {
        setSeciliEtkinlik(prev => ({
          ...prev,
          mesajlar: [...(prev.mesajlar || []), sonuc.mesaj]
        }));
        setYeniMesaj('');
      }
    } catch (error) {
      console.error('Mesaj gönderme hatası:', error);
    }
  };

  const handleKapat = () => {
    setModalAcik(null);
    setSeciliEtkinlik(null);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center">
      <div className={`${tema.bgCard} rounded-t-3xl w-full max-w-lg animate-slide-up border-t ${tema.border} max-h-[95vh] flex flex-col`}>
        <div className="p-6 border-b border-gray-100">
          <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
          
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 bg-gradient-to-br from-orange-400 to-amber-400 rounded-2xl flex items-center justify-center text-3xl shadow-lg">
                {etkinlikIkonlari[seciliEtkinlik.ikon]}
              </div>
              <div>
                <h3 className={`text-xl font-black ${tema.text}`}>{seciliEtkinlik.baslik}</h3>
                <p className={tema.textSecondary}>{seciliEtkinlik.grup?.emoji} {seciliEtkinlik.grup?.isim}</p>
              </div>
            </div>
            <button type="button" onClick={handleKapat} className={`w-10 h-10 rounded-xl ${tema.inputBg} flex items-center justify-center ${tema.text}`}>✕</button>
          </div>

          <div className="grid grid-cols-2 gap-3 mb-4">
            <div className={`${tema.inputBg} rounded-xl p-3`}>
              <div className={`text-xs ${tema.textMuted} mb-1`}>📅 Tarih</div>
              <div className={`font-bold ${tema.text}`}>{gunlerTam[tarih.getDay()]}</div>
              <div className={`text-sm ${tema.textSecondary}`}>{tarih.getDate()} {aylar[tarih.getMonth()]}</div>
            </div>
            <div className={`${tema.inputBg} rounded-xl p-3`}>
              <div className={`text-xs ${tema.textMuted} mb-1`}>⏰ Saat</div>
              <div className={`font-bold ${tema.text}`}>{seciliEtkinlik.saat}</div>
              <div className={`text-sm ${tema.textSecondary}`}>📍 {seciliEtkinlik.mekan}</div>
            </div>
          </div>

          <div className="flex gap-2 mb-4">
            {[
              { durum: 'varim', label: '✓ Varım', color: 'from-green-500 to-emerald-500' },
              { durum: 'bakariz', label: '🤔 Bakarız', color: 'from-yellow-500 to-orange-500' },
              { durum: 'yokum', label: '✗ Yokum', color: 'from-red-500 to-rose-500' },
            ].map(btn => (
              <button
                key={btn.durum}
                type="button"
                onClick={() => katilimDurumuGuncelle(seciliEtkinlik.id, btn.durum)}
                className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all ${
                  kullanicininDurumu === btn.durum
                    ? `bg-gradient-to-r ${btn.color} text-white shadow-lg scale-105`
                    : `${tema.inputBg} ${tema.text} ${tema.bgHover}`
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>

          <div>
            <div className={`text-sm font-bold ${tema.textSecondary} mb-2`}>Katılımcılar ({varimSayisi}/{katilimcilar.length})</div>
            <div className="flex flex-wrap gap-2">
              {katilimcilar.length > 0 ? katilimcilar.map((k, i) => (
                <div 
                  key={i}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-sm ${
                    k.durum === 'varim' ? 'bg-green-100 text-green-700' :
                    k.durum === 'bakariz' ? 'bg-yellow-100 text-yellow-700' :
                    k.durum === 'yokum' ? 'bg-red-100 text-red-700' :
                    `${tema.inputBg} ${tema.text}`
                  }`}
                >
                  <span className="font-medium">{k.odUserId === kullanici?.odUserId ? 'Sen' : 'Katılımcı'}</span>
                </div>
              )) : (
                <p className={tema.textSecondary}>Henüz katılımcı yok</p>
              )}
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {(seciliEtkinlik.mesajlar || []).map((m, i) => (
            <div key={i} className={`flex gap-2 ${m.odUserId === kullanici?.odUserId ? 'flex-row-reverse' : ''}`}>
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-orange-400 to-amber-400 flex items-center justify-center text-sm">
                {m.avatar || '👤'}
              </div>
              <div className={`max-w-[70%] ${m.odUserId === kullanici?.odUserId ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white' : tema.inputBg} rounded-2xl px-4 py-2`}>
                <div className={`text-xs ${m.odUserId === kullanici?.odUserId ? 'text-white/70' : tema.textMuted}`}>{m.isim || 'Kullanıcı'}</div>
                <div className={m.odUserId === kullanici?.odUserId ? 'text-white' : tema.text}>{m.mesaj}</div>
                <div className={`text-xs ${m.odUserId === kullanici?.odUserId ? 'text-white/50' : tema.textMuted} text-right`}>{m.zaman}</div>
              </div>
            </div>
          ))}
          {(!seciliEtkinlik.mesajlar || seciliEtkinlik.mesajlar.length === 0) && (
            <div className="text-center py-8">
              <span className="text-4xl">💬</span>
              <p className={`${tema.textSecondary} mt-2`}>Henüz mesaj yok</p>
            </div>
          )}
        </div>

        <div className={`p-4 border-t ${tema.border}`}>
          <div className="flex gap-2">
            <input
              type="text"
              value={yeniMesaj}
              onChange={(e) => setYeniMesaj(e.target.value)}
              placeholder="Mesaj yaz..."
              onKeyPress={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  mesajGonder(e);
                }
              }}
              className={`flex-1 ${tema.inputBg} ${tema.inputText} rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-orange-400`}
            />
            <button
              type="button"
              onClick={(e) => mesajGonder(e)}
              className="w-12 h-12 bg-gradient-to-r from-orange-500 to-amber-500 rounded-xl flex items-center justify-center text-white"
            >
              📤
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EtkinlikDetayModal;
