import React, { useState } from 'react';

const gunlerTam = ['Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi'];
const aylar = ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'];
const etkinlikIkonlari = { kahve: '☕', yemek: '🍕', film: '🎬', spor: '⚽', oyun: '🎮', parti: '🎉', toplanti: '💼', gezi: '🏖️', alisveris: '🛍️', konser: '🎵', diger: '📅' };
const mekanOnerileri = [
  { isim: 'Starbucks Moda', emoji: '☕' },
  { isim: 'Big Chefs', emoji: '🍽️' },
  { isim: 'Cinemaximum', emoji: '🎬' },
  { isim: 'Playstation Cafe', emoji: '🎮' },
];

const YeniPlanModal = ({ modalAcik, setModalAcik, seciliZaman, seciliGrup, gruplar, yeniEtkinlikOlustur, islemYukleniyor, bildirimGoster, tema }) => {
  const [baslik, setBaslik] = useState('');
  const [secilenIkon, setSecilenIkon] = useState('kahve');
  const [mekan, setMekan] = useState('');
  const [secilenGrupId, setSecilenGrupId] = useState(seciliGrup?.id || gruplar[0]?.id);

  if (modalAcik !== 'yeniPlan' || !seciliZaman) return null;

  const handleOlustur = async () => {
    if (!baslik.trim()) {
      bildirimGoster('Plan adı gerekli!', 'hata');
      return;
    }

    const hedefGrup = gruplar.find(g => g.id === secilenGrupId);
    
    if (!hedefGrup) {
      bildirimGoster('Lütfen bir grup seç!', 'hata');
      return;
    }

    await yeniEtkinlikOlustur({
      baslik,
      ikon: secilenIkon,
      tarih: seciliZaman.tarih,
      saat: seciliZaman.saat,
      mekan: mekan || 'Belirtilmedi',
      grup: hedefGrup
    });
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center">
      <div className={`${tema.bgCard} rounded-t-3xl w-full max-w-lg p-6 animate-slide-up border-t ${tema.border} max-h-[90vh] overflow-y-auto`}>
        <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
        
        <div className="flex items-center justify-between mb-6">
          <h3 className={`text-xl font-black ${tema.text}`}>🎉 Yeni Plan</h3>
          <button type="button" onClick={() => setModalAcik(null)} className={`w-10 h-10 rounded-xl ${tema.inputBg} flex items-center justify-center ${tema.text}`}>✕</button>
        </div>

        <div className={`${tema.inputBg} rounded-2xl p-4 mb-4 flex items-center gap-3`}>
          <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-amber-400 rounded-xl flex items-center justify-center text-2xl">📅</div>
          <div>
            <div className={`font-bold ${tema.text}`}>{gunlerTam[seciliZaman.tarih.getDay()]}</div>
            <div className={tema.textSecondary}>{seciliZaman.tarih.getDate()} {aylar[seciliZaman.tarih.getMonth()]} • {seciliZaman.saat}</div>
          </div>
        </div>

        <div className="mb-4">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>Plan Adı</label>
          <input
            type="text"
            value={baslik}
            onChange={(e) => setBaslik(e.target.value)}
            placeholder="Kahve içelim mi?"
            className={`w-full ${tema.inputBg} ${tema.inputText} rounded-2xl p-4 border-2 border-transparent focus:border-orange-400 focus:outline-none`}
          />
        </div>

        <div className="mb-4">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>Kategori</label>
          <div className="flex flex-wrap gap-2">
            {Object.entries(etkinlikIkonlari).map(([key, icon]) => (
              <button
                key={key}
                type="button"
                onClick={() => setSecilenIkon(key)}
                className={`w-11 h-11 rounded-xl text-xl flex items-center justify-center transition-all ${
                  secilenIkon === key
                    ? 'bg-gradient-to-br from-orange-400 to-amber-400 shadow-lg scale-110'
                    : `${tema.inputBg} ${tema.bgHover}`
                }`}
              >
                {icon}
              </button>
            ))}
          </div>
        </div>

        <div className="mb-4">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>👥 Grup Seç</label>
          {gruplar.length > 0 ? (
            <div className="space-y-2">
              {gruplar.map(g => (
                <button
                  key={g.id}
                  type="button"
                  onClick={() => setSecilenGrupId(g.id)}
                  className={`w-full flex items-center gap-3 p-3 rounded-xl transition-all ${
                    secilenGrupId === g.id
                      ? 'bg-orange-100 border-2 border-orange-400'
                      : `${tema.inputBg} border-2 border-transparent`
                  }`}
                >
                  <span className="text-2xl">{g.emoji}</span>
                  <span className={`font-medium ${tema.text}`}>{g.isim}</span>
                </button>
              ))}
            </div>
          ) : (
            <div className={`${tema.inputBg} rounded-xl p-4 text-center`}>
              <p className={tema.textSecondary}>Henüz grup yok!</p>
              <button type="button" onClick={() => setModalAcik('yeniGrup')} className="text-orange-500 font-bold mt-2">
                + Önce Grup Oluştur
              </button>
            </div>
          )}
        </div>

        <div className="mb-4">
          <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>📍 Mekan</label>
          <input
            type="text"
            value={mekan}
            onChange={(e) => setMekan(e.target.value)}
            placeholder="Starbucks Moda"
            className={`w-full ${tema.inputBg} ${tema.inputText} rounded-2xl p-4 border-2 border-transparent focus:border-orange-400 focus:outline-none`}
          />
          
          <div className="flex gap-2 mt-2 overflow-x-auto pb-2">
            {mekanOnerileri.map((m, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setMekan(m.isim)}
                className={`${tema.inputBg} px-3 py-2 rounded-xl text-sm whitespace-nowrap flex items-center gap-1 ${tema.text} ${tema.bgHover}`}
              >
                {m.emoji} {m.isim}
              </button>
            ))}
          </div>
        </div>

        <button
          type="button"
          onClick={handleOlustur}
          disabled={islemYukleniyor || gruplar.length === 0}
          className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white py-4 rounded-2xl font-bold text-lg shadow-lg disabled:opacity-50"
        >
          {islemYukleniyor ? '⏳ Oluşturuluyor...' : 'Plan Oluştur 🚀'}
        </button>
      </div>
    </div>
  );
};

export default YeniPlanModal;
