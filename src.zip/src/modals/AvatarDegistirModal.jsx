import React from 'react';

const avatarlar = {
  erkek: ['👨', '👨‍🦱', '👨‍🦰', '👨‍🦳', '👨‍🦲', '🧔', '🧔‍♂️', '👱‍♂️', '👨‍🎓', '👨‍💼', '👨‍🔧', '👨‍🍳', '👨‍🎨', '👨‍🚀', '🕵️‍♂️', '👨‍⚕️', '👨‍🏫', '🤴', '🦸‍♂️', '🧙‍♂️'],
  kadin: ['👩', '👩‍🦱', '👩‍🦰', '👩‍🦳', '👱‍♀️', '👩‍🎓', '👩‍💼', '👩‍🔧', '👩‍🍳', '👩‍🎨', '👩‍🚀', '🕵️‍♀️', '👩‍⚕️', '👩‍🏫', '👸', '🦸‍♀️', '🧙‍♀️', '🧕', '👰', '🤱'],
  fantastik: ['🤖', '👽', '👻', '🎃', '😺', '🦊', '🐶', '🐱', '🦁', '🐯', '🐻', '🐼', '🐨', '🐸', '🦄', '🐲', '🦋', '🌸', '⭐', '🌈']
};

const AvatarDegistirModal = ({ modalAcik, setModalAcik, seciliAvatar, setSeciliAvatar, avatarKategori, setAvatarKategori, setKullanici, bildirimGoster, tema }) => {
  if (modalAcik !== 'avatarDegistir') return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center">
      <div className={`${tema.bgCard} rounded-t-3xl w-full max-w-lg p-6 animate-slide-up border-t ${tema.border}`}>
        <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
        
        <div className="flex items-center justify-between mb-4">
          <h3 className={`text-xl font-black ${tema.text}`}>🎨 Avatar Seç</h3>
          <button type="button" onClick={() => setModalAcik(null)} className={`w-10 h-10 rounded-xl ${tema.inputBg} flex items-center justify-center ${tema.text}`}>✕</button>
        </div>

        <div className="flex justify-center gap-2 mb-4">
          {['erkek', 'kadin', 'fantastik'].map(kat => (
            <button
              key={kat}
              type="button"
              onClick={() => setAvatarKategori(kat)}
              className={`w-12 h-12 rounded-xl text-2xl transition-all ${
                avatarKategori === kat
                  ? 'bg-gradient-to-r from-orange-500 to-amber-500 shadow-lg scale-110'
                  : tema.inputBg
              }`}
            >
              {kat === 'erkek' ? '👨' : kat === 'kadin' ? '👩' : '🦄'}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-5 gap-3 max-h-64 overflow-y-auto mb-4">
          {avatarlar[avatarKategori].map((avatar, i) => (
            <button
              key={i}
              type="button"
              onClick={() => setSeciliAvatar(avatar)}
              className={`w-14 h-14 rounded-2xl text-3xl flex items-center justify-center transition-all ${
                seciliAvatar === avatar
                  ? 'bg-gradient-to-br from-orange-400 to-amber-400 shadow-lg scale-110 ring-4 ring-orange-300'
                  : `${tema.inputBg} ${tema.bgHover}`
              }`}
            >
              {avatar}
            </button>
          ))}
        </div>

        <button
          type="button"
          onClick={() => {
            setKullanici(prev => ({ ...prev, avatar: seciliAvatar }));
            setModalAcik(null);
            bildirimGoster('Avatar güncellendi! ✨');
          }}
          className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white py-4 rounded-2xl font-bold shadow-lg"
        >
          Kaydet
        </button>
      </div>
    </div>
  );
};

export default AvatarDegistirModal;
