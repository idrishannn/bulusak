import React from 'react';

const BildirimlerModal = ({ modalAcik, setModalAcik, bildirimler, tema }) => {
  if (modalAcik !== 'bildirimler') return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-end justify-center">
      <div className={`${tema.bgCard} rounded-t-3xl w-full max-w-lg p-6 animate-slide-up border-t ${tema.border} max-h-[70vh]`}>
        <div className="w-12 h-1 bg-gray-300 rounded-full mx-auto mb-4"></div>
        
        <div className="flex items-center justify-between mb-4">
          <h3 className={`text-xl font-black ${tema.text}`}>🔔 Bildirimler</h3>
          <button type="button" onClick={() => setModalAcik(null)} className={`w-10 h-10 rounded-xl ${tema.inputBg} flex items-center justify-center ${tema.text}`}>✕</button>
        </div>

        <div className="space-y-3 overflow-y-auto">
          {bildirimler.length > 0 ? bildirimler.map(b => (
            <div 
              key={b.id}
              className={`flex items-center gap-3 p-4 rounded-2xl ${b.okundu ? tema.inputBg : 'bg-orange-50'}`}
            >
              <div className={`w-3 h-3 rounded-full ${b.okundu ? 'bg-gray-300' : 'bg-orange-500'}`}></div>
              <div className="flex-1">
                <p className={`font-medium ${tema.text}`}>{b.mesaj}</p>
                <p className={`text-sm ${tema.textMuted}`}>{b.zaman}</p>
              </div>
            </div>
          )) : (
            <div className="text-center py-8">
              <span className="text-4xl">🔕</span>
              <p className={`${tema.textSecondary} mt-2`}>Henüz bildirim yok</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BildirimlerModal;
