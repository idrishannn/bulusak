import React from 'react';

const avatarlar = {
  erkek: ['👨', '👨‍🦱', '👨‍🦰', '👨‍🦳', '👨‍🦲', '🧔', '🧔‍♂️', '👱‍♂️', '👨‍🎓', '👨‍💼', '👨‍🔧', '👨‍🍳', '👨‍🎨', '👨‍🚀', '🕵️‍♂️', '👨‍⚕️', '👨‍🏫', '🤴', '🦸‍♂️', '🧙‍♂️'],
  kadin: ['👩', '👩‍🦱', '👩‍🦰', '👩‍🦳', '👱‍♀️', '👩‍🎓', '👩‍💼', '👩‍🔧', '👩‍🍳', '👩‍🎨', '👩‍🚀', '🕵️‍♀️', '👩‍⚕️', '👩‍🏫', '👸', '🦸‍♀️', '🧙‍♀️', '🧕', '👰', '🤱'],
  fantastik: ['🤖', '👽', '👻', '🎃', '😺', '🦊', '🐶', '🐱', '🦁', '🐯', '🐻', '🐼', '🐨', '🐸', '🦄', '🐲', '🦋', '🌸', '⭐', '🌈']
};

const AvatarSecim = ({ setKayitAsamasi, seciliAvatar, setSeciliAvatar, avatarKategori, setAvatarKategori, tema }) => {
  return (
    <div className={`min-h-screen ${tema.bg} flex flex-col`}>
      <div className="p-4 flex items-center">
        <button onClick={() => setKayitAsamasi('giris')} className={`${tema.text} text-2xl`}>←</button>
      </div>

      <div className="flex-1 p-6">
        <div className="text-center mb-6">
          <h2 className={`text-2xl font-black ${tema.text}`}>Avatarını Seç 🎨</h2>
          <p className={tema.textSecondary}>Seni en iyi yansıtan avatarı bul</p>
        </div>

        <div className="flex justify-center mb-6">
          <div className="w-28 h-28 bg-gradient-to-br from-orange-400 to-amber-400 rounded-3xl flex items-center justify-center text-6xl shadow-2xl animate-bounce-slow">
            {seciliAvatar}
          </div>
        </div>

        <div className="flex justify-center gap-2 mb-4">
          {[
            { key: 'erkek', label: '👨 Erkek' },
            { key: 'kadin', label: '👩 Kadın' },
            { key: 'fantastik', label: '🦄 Fantastik' },
          ].map(kat => (
            <button
              key={kat.key}
              onClick={() => setAvatarKategori(kat.key)}
              className={`px-4 py-2 rounded-xl font-medium transition-all ${
                avatarKategori === kat.key
                  ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-lg'
                  : `${tema.bgCard} ${tema.text} border ${tema.border}`
              }`}
            >
              {kat.label}
            </button>
          ))}
        </div>

        <div className={`${tema.bgCard} rounded-3xl p-4 border ${tema.border} ${tema.cardShadow}`}>
          <div className="grid grid-cols-5 gap-3 max-h-64 overflow-y-auto">
            {avatarlar[avatarKategori].map((avatar, i) => (
              <button
                key={i}
                onClick={() => setSeciliAvatar(avatar)}
                className={`w-14 h-14 rounded-2xl text-3xl flex items-center justify-center transition-all ${
                  seciliAvatar === avatar
                    ? 'bg-gradient-to-br from-orange-400 to-amber-400 shadow-lg scale-110 ring-4 ring-orange-300'
                    : `${tema.inputBg} ${tema.bgHover}`
                }`}
              >
                {avatar}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="p-6">
        <button
          onClick={() => setKayitAsamasi('bilgi')}
          className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white py-4 rounded-2xl font-bold text-lg shadow-lg"
        >
          Devam Et →
        </button>
      </div>
    </div>
  );
};

export default AvatarSecim;
