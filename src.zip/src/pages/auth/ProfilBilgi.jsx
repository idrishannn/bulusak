import React, { useState } from 'react';
import { auth } from '../../services';
import { profilGuncelle } from '../../services';

const ProfilBilgi = ({ setKayitAsamasi, seciliAvatar, setKullanici, setGirisYapildi, bildirimGoster, tema }) => {
  const [isim, setIsim] = useState('');
  const [kullaniciAdi, setKullaniciAdi] = useState('');
  const [kayitYukleniyor, setKayitYukleniyor] = useState(false);

  const tamamla = async () => {
    if (!auth.currentUser) {
      bildirimGoster('Önce Google ile giriş yapmalısın!', 'hata');
      setKayitAsamasi('giris');
      return;
    }
    
    setKayitYukleniyor(true);
    const userId = auth.currentUser.uid;
    
    const result = await profilGuncelle(userId, {
      isim: isim || 'Kullanıcı',
      kullaniciAdi: kullaniciAdi ? `@${kullaniciAdi.replace('@', '')}` : `@kullanici${Date.now()}`,
      avatar: seciliAvatar,
      online: true,
      bio: ''
    });
    
    if (result.success) {
      setKullanici({
        id: userId,
        odUserId: userId,
        isim: isim || 'Kullanıcı',
        kullaniciAdi: kullaniciAdi ? `@${kullaniciAdi.replace('@', '')}` : `@kullanici${Date.now()}`,
        avatar: seciliAvatar,
        online: true,
        bio: ''
      });
      setGirisYapildi(true);
      bildirimGoster('Hoş geldin! 🎉');
    } else {
      bildirimGoster('Kayıt hatası!', 'hata');
    }
    setKayitYukleniyor(false);
  };

  return (
    <div className={`min-h-screen ${tema.bg} flex flex-col`}>
      <div className="p-4 flex items-center">
        <button onClick={() => setKayitAsamasi('avatar')} className={`${tema.text} text-2xl`}>←</button>
      </div>

      <div className="flex-1 p-6">
        <div className="text-center mb-8">
          <div className="w-24 h-24 bg-gradient-to-br from-orange-400 to-amber-400 rounded-3xl flex items-center justify-center text-5xl mx-auto mb-4 shadow-2xl">
            {seciliAvatar}
          </div>
          <h2 className={`text-2xl font-black ${tema.text}`}>Son Adım! 🚀</h2>
          <p className={tema.textSecondary}>Profilini tamamla</p>
        </div>

        <div className="space-y-4">
          <div>
            <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>İsmin</label>
            <input
              type="text"
              value={isim}
              onChange={(e) => setIsim(e.target.value)}
              placeholder="Ahmet"
              className={`w-full ${tema.inputBg} ${tema.inputText} rounded-2xl p-4 border-2 border-transparent focus:border-orange-400 focus:outline-none transition-all`}
            />
          </div>

          <div>
            <label className={`text-sm font-bold ${tema.textSecondary} mb-2 block`}>Kullanıcı Adı</label>
            <div className="relative">
              <span className={`absolute left-4 top-1/2 -translate-y-1/2 ${tema.textMuted}`}>@</span>
              <input
                type="text"
                value={kullaniciAdi}
                onChange={(e) => setKullaniciAdi(e.target.value.replace('@', ''))}
                placeholder="ahmet"
                className={`w-full ${tema.inputBg} ${tema.inputText} rounded-2xl p-4 pl-8 border-2 border-transparent focus:border-orange-400 focus:outline-none transition-all`}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="p-6">
        <button
          onClick={tamamla}
          disabled={kayitYukleniyor}
          className="w-full bg-gradient-to-r from-orange-500 to-amber-500 text-white py-4 rounded-2xl font-bold text-lg shadow-lg disabled:opacity-50"
        >
          {kayitYukleniyor ? '⏳ Kaydediliyor...' : 'Başlayalım! 🎉'}
        </button>
      </div>
    </div>
  );
};

export default ProfilBilgi;
