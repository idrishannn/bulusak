export { default as GirisEkrani } from './GirisEkrani';
export { default as AvatarSecim } from './AvatarSecim';
export { default as ProfilBilgi } from './ProfilBilgi';
