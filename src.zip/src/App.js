import React, { useState, useEffect } from 'react';

// Services
import { 
  googleIleGiris, 
  cikisYap, 
  kullaniciBilgisiGetir, 
  profilGuncelle,
  gruplariDinle,
  grupOlustur,
  etkinlikleriDinle,
  etkinlikOlustur,
  auth
} from './services';

// Pages
import { Feed, Takvim, Planlar, Profil, GirisEkrani, AvatarSecim, ProfilBilgi } from './pages';

// Modals
import { 
  YeniGrupModal, 
  YeniPlanModal, 
  HizliPlanModal, 
  EtkinlikDetayModal, 
  BucketListModal, 
  BildirimlerModal, 
  GaleriModal, 
  AvatarDegistirModal 
} from './modals';

// ============================================
// TEMA
// ============================================
const tema = {
  bg: 'bg-gradient-to-br from-orange-50 via-amber-50 to-orange-100',
  bgSecondary: 'bg-white/60',
  bgCard: 'bg-white',
  bgHover: 'hover:bg-orange-50',
  text: 'text-gray-800',
  textSecondary: 'text-gray-600',
  textMuted: 'text-gray-500',
  border: 'border-orange-100',
  inputBg: 'bg-gray-50',
  inputText: 'text-gray-800 placeholder-gray-400',
  gradient: 'from-orange-500 via-amber-500 to-orange-400',
  cardShadow: 'shadow-lg shadow-orange-100/50'
};

// ============================================
// ANA UYGULAMA
// ============================================
export default function BulusakApp() {
  // Auth State
  const [girisYapildi, setGirisYapildi] = useState(false);
  const [kayitAsamasi, setKayitAsamasi] = useState('giris');
  const [kullanici, setKullanici] = useState(null);
  const [yukleniyor, setYukleniyor] = useState(true);
  const [islemYukleniyor, setIslemYukleniyor] = useState(false);
  
  // Navigation State
  const [aktifSayfa, setAktifSayfa] = useState('feed');
  const [seciliGrup, setSeciliGrup] = useState(null);
  const [musaitlikler, setMusaitlikler] = useState({});
  
  // Data State
  const [gruplar, setGruplar] = useState([]);
  const [etkinlikler, setEtkinlikler] = useState([]);
  const [aktiviteler, setAktiviteler] = useState([]);
  
  // UI State
  const [katilimIstekleri, setKatilimIstekleri] = useState([]);
  const [bildirim, setBildirim] = useState(null);
  const [canSikildiModu, setCanSikildiModu] = useState(false);
  const [modalAcik, setModalAcik] = useState(null);
  const [seciliZaman, setSeciliZaman] = useState(null);
  const [seciliEtkinlik, setSeciliEtkinlik] = useState(null);
  const [seciliAvatar, setSeciliAvatar] = useState('👨');
  const [avatarKategori, setAvatarKategori] = useState('erkek');
  
  // Extra State
  const [bucketList, setBucketList] = useState([]);
  const [bildirimler, setBildirimler] = useState([]);
  const [galeri, setGaleri] = useState([]);

  // ============================================
  // EFFECTS
  // ============================================
  
  // Firebase Auth Listener
  useEffect(() => {
    const unsubscribeAuth = auth.onAuthStateChanged(async (user) => {
      if (user) {
        const userData = await kullaniciBilgisiGetir(user.uid);
        if (userData && userData.profilTamamlandi) {
          setKullanici({ ...userData, id: user.uid, odUserId: user.uid });
          setGirisYapildi(true);
          setKayitAsamasi('giris');
        } else {
          setGirisYapildi(false);
          setKayitAsamasi('avatar');
        }
      } else {
        setKullanici(null);
        setGirisYapildi(false);
        setKayitAsamasi('giris');
      }
      setYukleniyor(false);
    });
    return () => unsubscribeAuth();
  }, []);

  // Grupları dinle
  useEffect(() => {
    if (kullanici?.odUserId) {
      const unsubscribe = gruplariDinle(kullanici.odUserId, setGruplar);
      return () => unsubscribe();
    }
  }, [kullanici?.odUserId]);

  // Etkinlikleri dinle
  useEffect(() => {
    if (gruplar.length > 0) {
      const grupIds = gruplar.map(g => g.id);
      const unsubscribe = etkinlikleriDinle(grupIds, setEtkinlikler);
      return () => unsubscribe();
    }
  }, [gruplar]);

  // ============================================
  // HELPER FUNCTIONS
  // ============================================

  const bildirimGoster = (mesaj, tip = 'basari') => {
    setBildirim({ mesaj, tip });
    setTimeout(() => setBildirim(null), 3000);
  };

  const musaitlikToggle = (tarih, saat) => {
    const key = `${tarih.toDateString()}-${saat}`;
    setMusaitlikler(prev => ({ ...prev, [key]: !prev[key] }));
  };

  // ============================================
  // AUTH FUNCTIONS
  // ============================================

  const googleIleGirisYap = async () => {
    setIslemYukleniyor(true);
    try {
      const result = await googleIleGiris();
      if (result.success) {
        if (result.isNewUser) {
          setKayitAsamasi('avatar');
        } else {
          const userData = await kullaniciBilgisiGetir(result.user.uid);
          if (userData && userData.profilTamamlandi) {
            setKullanici({ ...userData, id: result.user.uid, odUserId: result.user.uid });
            setGirisYapildi(true);
            bildirimGoster('Tekrar hoş geldin! 🎉');
          } else {
            setKayitAsamasi('avatar');
          }
        }
      } else {
        bildirimGoster('Giriş başarısız: ' + result.error, 'hata');
      }
    } catch (error) {
      bildirimGoster('Bir hata oluştu!', 'hata');
    }
    setIslemYukleniyor(false);
  };

  const cikisYapFunc = async () => {
    try {
      await cikisYap();
      setKullanici(null);
      setGirisYapildi(false);
      setKayitAsamasi('giris');
      setGruplar([]);
      setEtkinlikler([]);
      bildirimGoster('Çıkış yapıldı!');
    } catch (error) {
      console.error('Çıkış hatası:', error);
    }
  };

  // ============================================
  // CRUD FUNCTIONS
  // ============================================

  const yeniGrupOlustur = async (isim, emoji, uyeler) => {
    if (!kullanici?.odUserId) {
      bildirimGoster('Önce giriş yapmalısın!', 'hata');
      return null;
    }
    setIslemYukleniyor(true);
    const result = await grupOlustur({ isim, emoji, renk: '#FF6B35' }, kullanici.odUserId);
    setIslemYukleniyor(false);
    if (result.success) {
      bildirimGoster(`${emoji} ${isim} oluşturuldu!`);
      return { id: result.id, isim, emoji, uyeler: [kullanici.odUserId], renk: '#FF6B35' };
    } else {
      bildirimGoster('Grup oluşturulamadı!', 'hata');
      return null;
    }
  };

  const yeniEtkinlikOlustur = async (data) => {
    if (!kullanici?.odUserId) {
      bildirimGoster('Önce giriş yapmalısın!', 'hata');
      return false;
    }
    if (!data.grup || !data.grup.id) {
      bildirimGoster('Lütfen bir grup seç!', 'hata');
      return false;
    }
    setIslemYukleniyor(true);
    const result = await etkinlikOlustur({
      baslik: data.baslik,
      ikon: data.ikon,
      grupId: data.grup.id,
      grup: data.grup,
      tarih: data.tarih.toISOString(),
      saat: data.saat,
      mekan: data.mekan
    }, kullanici.odUserId);
    setIslemYukleniyor(false);
    if (result.success) {
      bildirimGoster('Plan oluşturuldu! 🎉');
      setModalAcik(null);
      return true;
    } else {
      bildirimGoster('Plan oluşturulamadı!', 'hata');
      return false;
    }
  };

  const katilimDurumuGuncelle = (etkinlikId, durum) => {
    setEtkinlikler(prev => prev.map(e => {
      if (e.id === etkinlikId) {
        const mevcutKatilimci = e.katilimcilar?.find(k => k.odUserId === kullanici?.odUserId);
        if (mevcutKatilimci) {
          return { ...e, katilimcilar: e.katilimcilar.map(k => k.odUserId === kullanici?.odUserId ? { ...k, durum } : k) };
        } else {
          return { ...e, katilimcilar: [...(e.katilimcilar || []), { odUserId: kullanici?.odUserId, durum }] };
        }
      }
      return e;
    }));
    bildirimGoster(durum === 'varim' ? 'Katılım onaylandı! ✓' : durum === 'bakariz' ? 'Belki katılacaksın 🤔' : 'Katılmıyorsun ✗');
  };

  // ============================================
  // COMPONENTS
  // ============================================

  const Bildirim = () => {
    if (!bildirim) return null;
    return (
      <div className={`fixed top-4 left-1/2 transform -translate-x-1/2 z-[100] px-6 py-3 rounded-2xl shadow-2xl animate-bounce-in backdrop-blur-lg ${
        bildirim.tip === 'basari' ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white' : 'bg-red-500/90 text-white'
      }`}>
        <div className="flex items-center gap-2">
          <span>{bildirim.tip === 'basari' ? '✨' : '⚠️'}</span>
          {bildirim.mesaj}
        </div>
      </div>
    );
  };

  const Header = () => (
    <header className="bg-gradient-to-r from-orange-500 via-amber-500 to-orange-400 text-white shadow-2xl sticky top-0 z-40">
      <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-black tracking-tight leading-none">Buluşak</h1>
          <p className="text-sm text-white/80 font-medium">planla, buluş, yaşa</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setModalAcik('bildirimler')} className="relative w-11 h-11 bg-white/20 backdrop-blur-lg rounded-xl flex items-center justify-center hover:bg-white/30 transition-all">
            🔔
            {bildirimler.filter(b => !b.okundu).length > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full text-xs flex items-center justify-center font-bold">
                {bildirimler.filter(b => !b.okundu).length}
              </span>
            )}
          </button>
          <button onClick={() => setCanSikildiModu(!canSikildiModu)} className={`w-11 h-11 rounded-xl flex items-center justify-center transition-all ${canSikildiModu ? 'bg-white text-orange-500 shadow-lg' : 'bg-white/20 backdrop-blur-lg hover:bg-white/30'}`}>
            {canSikildiModu ? '🔥' : '😴'}
          </button>
        </div>
      </div>
    </header>
  );

  const AltNav = () => (
    <nav className={`fixed bottom-0 left-0 right-0 ${tema.bgCard} border-t ${tema.border} shadow-2xl z-40`}>
      <div className="max-w-lg mx-auto flex justify-around py-2">
        {[
          { id: 'feed', icon: '🏠', label: 'Akış' },
          { id: 'takvim', icon: '📅', label: 'Takvim' },
          { id: 'yeni', icon: '➕', label: 'Yeni', special: true },
          { id: 'planlar', icon: '📋', label: 'Planlar' },
          { id: 'profil', icon: '👤', label: 'Profil' },
        ].map(item => (
          <button
            key={item.id}
            onClick={() => item.id === 'yeni' ? setModalAcik('hizliPlan') : setAktifSayfa(item.id)}
            className={`relative flex flex-col items-center py-2 px-3 rounded-2xl transition-all duration-300 ${
              item.special ? 'bg-gradient-to-r from-orange-500 to-amber-500 text-white shadow-lg -mt-4 scale-110'
              : aktifSayfa === item.id ? 'text-orange-500 bg-orange-100 scale-105' : `${tema.textSecondary} ${tema.bgHover}`
            }`}
          >
            <span className={item.special ? 'text-2xl' : 'text-xl'}>{item.icon}</span>
            <span className="text-xs mt-1 font-semibold">{item.label}</span>
            {item.id === 'planlar' && katilimIstekleri.length > 0 && (
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-orange-500 rounded-full text-[10px] text-white flex items-center justify-center font-bold">
                {katilimIstekleri.length}
              </span>
            )}
          </button>
        ))}
      </div>
    </nav>
  );

  // ============================================
  // RENDER
  // ============================================

  // Yükleniyor
  if (yukleniyor) {
    return (
      <div className={`min-h-screen ${tema.bg} flex items-center justify-center`}>
        <div className="text-center">
          <div className="text-6xl mb-4 animate-bounce">🎉</div>
          <h1 className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-500 to-amber-500">Buluşak</h1>
          <p className={`${tema.textSecondary} mt-2`}>Yükleniyor...</p>
        </div>
      </div>
    );
  }

  // Auth Screens
  if (!girisYapildi) {
    return (
      <div>
        <style>{globalStyles}</style>
        <Bildirim />
        {kayitAsamasi === 'giris' && <GirisEkrani googleIleGirisYap={googleIleGirisYap} islemYukleniyor={islemYukleniyor} tema={tema} />}
        {kayitAsamasi === 'avatar' && <AvatarSecim setKayitAsamasi={setKayitAsamasi} seciliAvatar={seciliAvatar} setSeciliAvatar={setSeciliAvatar} avatarKategori={avatarKategori} setAvatarKategori={setAvatarKategori} tema={tema} />}
        {kayitAsamasi === 'bilgi' && <ProfilBilgi setKayitAsamasi={setKayitAsamasi} seciliAvatar={seciliAvatar} setKullanici={setKullanici} setGirisYapildi={setGirisYapildi} bildirimGoster={bildirimGoster} tema={tema} />}
      </div>
    );
  }

  // Main App
  return (
    <div className={`min-h-screen ${tema.bg} transition-colors duration-300`}>
      <style>{globalStyles}</style>
      <Bildirim />
      <Header />
      
      <main className="custom-scrollbar">
        {aktifSayfa === 'feed' && <Feed kullanici={kullanici} canSikildiModu={canSikildiModu} setModalAcik={setModalAcik} aktiviteler={aktiviteler} tema={tema} />}
        {aktifSayfa === 'takvim' && <Takvim seciliGrup={seciliGrup} setSeciliGrup={setSeciliGrup} gruplar={gruplar} etkinlikler={etkinlikler} musaitlikler={musaitlikler} musaitlikToggle={musaitlikToggle} setSeciliZaman={setSeciliZaman} setSeciliEtkinlik={setSeciliEtkinlik} setModalAcik={setModalAcik} tema={tema} />}
        {aktifSayfa === 'planlar' && <Planlar etkinlikler={etkinlikler} katilimIstekleri={katilimIstekleri} setSeciliEtkinlik={setSeciliEtkinlik} setModalAcik={setModalAcik} tema={tema} />}
        {aktifSayfa === 'profil' && <Profil kullanici={kullanici} etkinlikler={etkinlikler} gruplar={gruplar} setModalAcik={setModalAcik} setAktifSayfa={setAktifSayfa} cikisYapFunc={cikisYapFunc} tema={tema} />}
      </main>

      {/* MODALS */}
      <YeniGrupModal modalAcik={modalAcik} setModalAcik={setModalAcik} yeniGrupOlustur={yeniGrupOlustur} islemYukleniyor={islemYukleniyor} bildirimGoster={bildirimGoster} tema={tema} />
      <YeniPlanModal modalAcik={modalAcik} setModalAcik={setModalAcik} seciliZaman={seciliZaman} seciliGrup={seciliGrup} gruplar={gruplar} yeniEtkinlikOlustur={yeniEtkinlikOlustur} islemYukleniyor={islemYukleniyor} bildirimGoster={bildirimGoster} tema={tema} />
      <HizliPlanModal modalAcik={modalAcik} setModalAcik={setModalAcik} gruplar={gruplar} yeniGrupOlustur={yeniGrupOlustur} yeniEtkinlikOlustur={yeniEtkinlikOlustur} islemYukleniyor={islemYukleniyor} bildirimGoster={bildirimGoster} tema={tema} />
      <EtkinlikDetayModal modalAcik={modalAcik} setModalAcik={setModalAcik} seciliEtkinlik={seciliEtkinlik} setSeciliEtkinlik={setSeciliEtkinlik} kullanici={kullanici} katilimDurumuGuncelle={katilimDurumuGuncelle} tema={tema} />
      <BucketListModal modalAcik={modalAcik} setModalAcik={setModalAcik} bucketList={bucketList} setBucketList={setBucketList} bildirimGoster={bildirimGoster} tema={tema} />
      <BildirimlerModal modalAcik={modalAcik} setModalAcik={setModalAcik} bildirimler={bildirimler} tema={tema} />
      <GaleriModal modalAcik={modalAcik} setModalAcik={setModalAcik} galeri={galeri} setGaleri={setGaleri} bildirimGoster={bildirimGoster} tema={tema} />
      <AvatarDegistirModal modalAcik={modalAcik} setModalAcik={setModalAcik} seciliAvatar={seciliAvatar} setSeciliAvatar={setSeciliAvatar} avatarKategori={avatarKategori} setAvatarKategori={setAvatarKategori} setKullanici={setKullanici} bildirimGoster={bildirimGoster} tema={tema} />
      
      <AltNav />
    </div>
  );
}

// ============================================
// GLOBAL STYLES
// ============================================
const globalStyles = `
  @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800;900&display=swap');
  * { font-family: 'Nunito', sans-serif; }
  .scrollbar-hide::-webkit-scrollbar { display: none; }
  .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
  @keyframes bounce-in { 0% { transform: translate(-50%, -100px); opacity: 0; } 50% { transform: translate(-50%, 10px); } 100% { transform: translate(-50%, 0); opacity: 1; } }
  @keyframes slide-up { from { transform: translateY(100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
  @keyframes scale-in { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
  @keyframes gradient-x { 0%, 100% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } }
  @keyframes bounce-slow { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-10px); } }
  .animate-bounce-in { animation: bounce-in 0.5s ease-out; }
  .animate-slide-up { animation: slide-up 0.3s ease-out; }
  .animate-scale-in { animation: scale-in 0.3s ease-out; }
  .animate-gradient-x { background-size: 200% 200%; animation: gradient-x 3s ease infinite; }
  .animate-bounce-slow { animation: bounce-slow 2s ease-in-out infinite; }
  .custom-scrollbar::-webkit-scrollbar { width: 6px; height: 6px; }
  .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
  .custom-scrollbar::-webkit-scrollbar-thumb { background: linear-gradient(to bottom, #FB923C, #F59E0B); border-radius: 10px; }
`;
